# 变更记录

## v1.5.3（2026-11-04）

### 1. README 一分为二

以前 `README.md` 既是技术说明、又当 GitHub 首页，两头都不讨好：访问者想看「这是什么」，接手的人想看「怎么装、有哪些坑」。

现在拆开：

| 文件 | 面向谁 | 内容 |
|---|---|---|
| `README.md` | 第一次点进来的人 | 它解决什么问题 / 不是什么 / 效果示例 / 架构图 / 隐私 / FAQ / 路线图 |
| `docs/pack-readme.md` | 要装、要改、要排查的人 | 方法表、九条铁律要点、技术要点、自动部署、日志与隐私、目录结构、版本变更 |

`docs/github-readme.md` 已删除（内容就是根 `README.md`，留着会双份维护）。

### 2. 合并作者在 GitHub 上直接改的文案

- 名字解释改为「取 Medical Literature Intelligence Assistant。yo 是标识」（原文写作 `Mediccal`，按拼写修正为 `Medical`）。
- 去掉顶部那段「本文件是仓库根 README 源文件」的 HTML 注释——README 已经在根目录，注释没用了。
- 去掉「## 目录」小标题，保留目录列表本身。

### 3. 顺带

- 技术说明里的相对链接按新位置修正（`docs/deploy.md` → `deploy.md`、`FEEDBACK.md` → `../FEEDBACK.md`）。
- 编辑器留下的 HTML 实体 `&#x4EA4;` 还原成「交」。


## v1.5.2（2026-11-04）

这一版只做一件事：**把「库与数据分开」从说法变成可验证的事实**。起因是发现打包器会跳过点文件——上传到 GitHub 的那份 zip 里根本没有 `.gitignore`，等于锁没装上。

### 1. 打包产物补上 `.gitignore` 与运行时目录占位

WorkBuddy 的 `package_expert.py` 会跳过以 `.` 开头的文件/目录，所以 `medical-lit-radar.zip` 里从来没有 `.gitignore`、`data/.gitkeep`、`logs/.gitkeep`。结果是：谁把 zip 传上 GitHub，谁就没有忽略规则，跑一次周报再 `git add .`，`data/*.json` 就直接进仓库了。

修法：打包后做一次**后处理注入**，往 zip 里补三条记录（`.gitignore`、`data/.gitkeep`、`logs/.gitkeep`），并把这一步写进发布流程。原来那份 `gitignore`（不带点的副本，因为打包器跳过点文件而做的妥协）随之删除——现在 zip 里是真的 `.gitignore`。

### 2. 清掉提示词库里的真实题录示例

按「`prompts/` 与 `agents/` 不得含真实题录」的口径自查，发现 4 处用了真实 PMID 当示例：

| 位置 | 原内容 | 改为 |
|---|---|---|
| `README.md` | `--pmid 36331121` + 真实摘要句式 | `--pmid 90000001`，并注明「示例为虚构」 |
| `bin/anchor.py` 文件头 | `--pmid 36331121`、`{"36331121": "摘要原文"}` | `90000001` + 一行「摘录与 PMID 均为虚构」 |
| `bin/ledger.py` 用法 | `--pmid 36331121` | `90000001` |
| `agents/medical-lit-radar.md` | tekmeria handle `pmid:30831578/abstract.7~ae2tc` | `pmid:90000001/...` |

`tests/fixtures/` 本来就是 90000001–3 的合成数据，未动。

### 3. 实测：git 只认这些，其余全忽略

在临时目录 `git init` + `git add -A`，并故意生成 `data/abstracts.json`、`data/expert.db`、`logs/setup.log`、`.env`、`secrets.txt`，结果：**只有 `.gitignore`、`data/.gitkeep`、`logs/.gitkeep` 及包本身的文本文件进入暂存区**，运行时产物全部 `!!` 忽略。


## v1.5.1（2026-11-04）

### 1. 安装改成「把包拖给 AI 装」

不再要求用户自己 `cp -r` 再敲注册命令。README 与 GitHub 页把最省事的方式提到最前：**把 zip 拖进对话框，贴一段部署指令，让 Agent 复制、校验、注册、回报**。指令里写死了三条纪律：先 `validate_expert.py` 再 `register_expert.py`、校验不过就停、不跳步骤。

新增 `docs/deploy.md`，按「省事程度」排三种装法：

| 场景 | 怎么装 |
|---|---|
| WorkBuddy（有专家中心） | 拖包 → 部署指令 → 重启 |
| DeepSeek Harness / 千问 Code / Claude Code / Cursor | 不用注册，`export_prompt.py` 设系统提示词 + `bin/` 放工作目录 |
| 网页版 ChatGPT / Claude / 千问 | 只能粘 `slim.md`，出不了带数字的周报 |

附手动三步与四个常见坑（不在专家目录、点进去空白、头像不刷新、路径含空格）。

### 2. 一致性与叙述复查（改掉 6 处）

| 问题 | 处理 |
|---|---|
| `--bg` 说明写「日志落 `~/.workbuddy/litradar/setup.log`」，与「默认不写日志」直接矛盾 | 改为「默认不写；要日志加 `--diagnose`」 |
| 「使用示例」还列着旧的三条 quickPrompt（第三条早已被替换） | 与卡片实际三条对齐 |
| `config.example.env` 写 `LITRADAR_AUTO_SETUP=1`，脚本读的却是 `LITRADAR_NO_AUTO_SETUP` | 统一为后者；`bootstrap.sh` 保留旧名兼容（`AUTO_SETUP=0` 也认） |
| `EXPERT_DIAGNOSE` 只出现在示例里，代码从未读取 | `bootstrap.sh` 现在真读它 |
| 反馈模板把版本写成固定值 `v1.4.0` / `v1.5.0`，每版都会滞后 | 改为「照抄 `plugin.json` 的 version」 |
| v1.2.0 历史条目里「`NOW-7DAYS` 等于显式 7 天窗」没标注已被推翻 | 加删除线 + 说明「v1.4.0 推翻，当时是无效测量」 |

### 3. 导出脚本标题层级

`prompts/feedback_guidance.md` 嵌进附录后，其 `#` 降为 `##`，与「## 附录」同级 → 再降一级（`###` / `####`）。


## v1.5.0（2026-11-04）

### 1. 新增 `bin/export_prompt.py`（可移植性）

专家包依赖 WorkBuddy 的 frontmatter（`name` / `displayName` / `maxTurns`），别的客户端不认。脚本做三件事：剥掉 frontmatter、补一段「运行环境说明」、可选附上反馈与隐私策略。

| 能力 | 说明 |
|---|---|
| `--check` | 只报体积与估算 token（完整版 21,266 字符 / 约 1.3–1.9 万 token） |
| `--out` | 写文件；省略则打印 stdout |
| `--format md|text|json` | `json` 输出 OpenAI 风格 `messages`，API 直接发 |
| `--no-runtime` / `--no-guidance` | 瘦身到 18,539 字符 / 约 1.1 万 token |

补的「运行环境说明」是一张能力表 + 三条硬规矩：没有 shell 就直说没有、不许编 hitCount 与 PMID；降级必须写进报告；窗口一律显式日历日。实测导出 JSON 可解析、H1 只有 1 个、附录正确降级标题。

### 2. 新增 `docs/portability.md`

- 三层拆解表：提示词层（换客户端 0 改动）/ 脚本层（要 Python 3.10+）/ MCP 层（标准 stdio，可选）
- 7 类客户端能力矩阵，明确写出「网页版 ChatGPT / Claude / Gemini：只能给检索式与框架，出不了带数字的周报」
- 四种接法：Claude Code（`CLAUDE.md` + `claude mcp add`）、Cursor（`.cursor/rules` + `.cursor/mcp.json`）、API（工具桥）、网页版（只能半程）
- 换模型后最先退化的三件事（窗口纪律 / 引用纪律 / 格式纪律）与对应的脚本兜底
- 新客户端自测清单：3 条命令 + 3 个问答题

### 3. 文档同步

README 增「接到别的 AI 里跑」整节并补目录结构；GitHub 展示页（`docs/github-readme.md`）增「换到别的模型」节、TOC、FAQ 一条、目录结构；版本号 1.5.0。


## v1.4.1（2026-11-04）

### 1. 引导词按「库分离」重写

首条 quickPrompt 与 `defaultInitPrompt`（两者必须一致）：

> 先介绍你能做什么、不能做什么、数据存在哪（本地、不上传），再告诉我怎么用你（**第一次使用前必问！！！**）

主提示词「第一次对话」从四件事扩到五件事，新增 **4）数据放在哪**，要求主动说清四句：仓库里只有提示词与合成示例；检索结果与中间产物只落本地 `data/`；日志默认不生成；不要邮箱、不索要邮箱。

同时加了一条硬规矩：**报告中间产物只写 `data/`（或用户指定目录），绝不写进 `prompts/` 或 `agents/`**——真实题录混进提示词库，等于把用户数据带进了要公开的库。

### 2. 仓库地址落地

`<OWNER>/<REPO>` → `yuuka3579379797-cmd/jingzheyo`，覆盖 plugin.json `homepage`、主提示词（6 处）、README、FEEDBACK、CONTRIBUTING、SECURITY、CODE_OF_CONDUCT、`config.example.env`、`prompts/feedback_guidance.md`。README 顶部加了仓库与「数据分离」说明。

### 3. 头像与许可

- 换成 `avatars/expert-v3.png`：512×512 PNG、377 KB，作者用 AI 绘图生成，无第三方版权。
- 旧图 `expert-v2.png` 删除；`LICENSE` 的「例外：头像文件」条款（原本声明头像不在 CC 范围内）删除，改为随包按 CC BY-NC-SA 4.0 授权。
- 改文件名而非覆盖同名文件，是为了绕开专家面板按路径缓存的旧图。

### 4. 简介

`displayDescription` 45 → 47 字：`检索式 + 精读 + 哈希锚定与反证，出可溯源中文周报；数据只存本地，仅限生物医学与生命科学。`


## v1.4.0（2026-11-03）

### 1. 窗口口径纠错（推翻 v1.3.0 的结论）

v1.3.0 写「`[NOW-7DAYS TO NOW]` 实测等于显式 7 天窗」，**这是错的**，来源是一次无效测量。

| 项 | 内容 |
|---|---|
| 上报 | 用户实跑：`NOW-7DAYS` 73 条 / 显式 7 日 85 条 / 显式 8 日 89 条（糖尿病肾病标志物，块 A 7 分支 × 块 B 35 分支） |
| 复现 | 2026-11-03 20:36 自测（糖尿病肾病主题）：49 / 62 / 71；`--json` 全量见 `bin/window.py verify` |
| 根因 | `NOW-7DAYS` 是**滚动 7×24 小时窗**，边界随"此刻"移动。20:36 运行时起点为 10-27 20:36，把起始日 00:00–20:36 整段切掉 |
| 边界日证据 | 起始日 2026-10-27 全天 4470 条，落在 NOW 窗内 **1** 条；今天 11-03 全天 5 条，5 条全进（当日并未被排除） |
| 为什么上次测错 | 上一轮在 **00:50** 跑、主题只有 14 条、且 10-27 当天该主题无记录 —— 两窗恰好近乎重合，14=14 是个空测试，不能证明等价 |

用户报告里"会排除当日白天发表的记录"一句与实测不符：被切掉的是**起始日**，当日是"只进已入库的部分"。这一点已在文档中按实测写明，没有照抄。

修正：
- 新增 `bin/window.py`：`dates` 按锚点算显式 `[起始日 TO 结束日]`（默认最近 N 个完整日历日、不含今天，避免与下期重叠）；`verify` 现场打三窗计数 + ID 差集 + 边界日实验，把"不等价"变成可复现的演示。
- 铁律 3 整条重写；数据获取章节、工作流第 3 步、README 技术要点/方法表/功能清单全部改为显式日历日。
- 交付门检查项 `query_consistency` 现在能兜住这类问题：报告里的式子必须与 `ledger.json` 完全一致，写 `NOW-N`DAYS 会在账本里留痕。

### 2. 改名

- `displayName` 与提示词自称改为 **YoMLIA**；技术 id 仍为 `medical-lit-radar`——改 id 会丢注册与市场条目，需要单独迁移。

### 3. 发布前安全收口

| 项 | 处理 |
|---|---|
| 个人邮箱 | 全部移除（提示词、README、FEEDBACK、plugin.json）。反馈只走 GitHub Discussions / Issues / 私有漏洞报告，`<OWNER>/<REPO>` 为占位符，发布前必须替换 |
| 日志 | 默认**不生成任何日志**；`--diagnose` 或 `EXPERT_LOG=1` 才写 `data/logs/setup.log`，写前把主目录替换为 `[HOME]`（posix 与 Windows 两种写法都处理），不记录 env 与完整 JSON |
| 数据分离 | 运行时产物（`abstracts/anchors/classes/ledger/mismatch.json`）落 `data/`，`.gitignore` 兜底；`data/` `logs/` 只留 `.gitkeep` |
| 新增文件 | `.gitignore`、`CONTRIBUTING.md`、`SECURITY.md`、`CODE_OF_CONDUCT.md`、`config.example.env`、`prompts/README.md`、`prompts/feedback_guidance.md` |
| 测试数据 | `tests/fixtures/` 全合成（PMID 90000001–3、虚构期刊），且**能跑通交付门 12/12**，作为"应当通过"的回归基线 |
| 提示词去数据 | 反馈章节改「不生成日志 / 不引导上传日志 / 不索要邮箱 / 不把用户数据写进提示词」，引用用户输入只用 `{{user_feedback}}` 这类占位符 |

### 4. 未做（留给下一版）

- `<OWNER>/<REPO>` 占位符需人工填写（涉及 6 个文件）——**v1.4.1 已填实**；
- 若本目录将成为 git 仓库，发布前需 `git log -p | grep` 自查历史里是否已混入邮箱或真实题录——本次未重写历史；
- `ledger.py` 的 `unregistered_numbers` 仍可能误伤正文里的派生数字，需要更多真实周报做误报率基准。


## v1.3.0（2026-11-03）

合并两条并行改动：**v1.2.0 的交付门改造**（他人提交）与**本地 v1.2.0 的反馈/自动部署**（本仓库）。合并时对前者的数字断言逐条复跑，能复现的采纳，复现不了的改写。

### 1. 新增 `bin/ledger.py`（交付门，零依赖）

- `check`：对周报**正文**做十二项机检；任一项不过 `exit 1`，文件/JSON 坏 `exit 2`，`--json` 给出可解析的失败项。
- `make`：生成单条锚定（PMID 不在 `abstracts.json` 里直接失败，取消单源兜底；跨段拼接拒收；上标/下标数字拒收）。
- `classify`：按 `勘误 > 预印本 > 述评 > 综述 > 无摘要 > 研究` 每条只落一类，断言六类之和 == 总数，并输出 `mesh_coverage`。
- 与 `anchor.py` 的分工：`anchor.py` 只比对锚定清单；`ledger.py check` 才读周报、才能绑定报告与原文。**L8 交付门改用 ledger.py**。
- 更正上一版说明：v1.2.0 文档里写「顺带修掉 `anchor.py` 的四个缺陷」不准确——`anchor.py` 一字未改，那四处问题是在 `ledger.py` 里规避的，旧脚本仍在。要用强校验请走 `ledger.py`。

### 2. 口径按实测修正（全部于 2026-11-03 复跑）

| 项 | 结论 | 实测 |
|---|---|---|
| 日期窗 | 采纳：`[NOW-7DAYS TO NOW]` 就是 7 天窗 | 14 条 = 显式 `[2026-10-27 TO 2026-11-02]` 14 条；`NOW-8DAYS` = 15 条 |
| 删除「多给一天」 | 采纳 | 旧建议会让每周窗与上期重叠一天 |
| `pageSize` 硬上限 | 采纳：1000 | 1001 → `errCode 404: Valid size is between 1 and 1000` |
| `sort` 必须带方向 | 采纳 | `P_PDATE_D` → HTTP 503；`P_PDATE_D desc` 正常 |
| 跨字段 OR 会静默算错 | 采纳，倍数改写 | 同日同题：组内一次窗口 313 条 vs 逐分支各带窗口 15 条 |
| MeSH 只能作辅助分支 | 采纳，比例改写 | 抽样 50 条：近 7 天缺 29（58%），近 30 天缺 26（52%） |
| 六类不能独立相加 | 采纳，数字改写 | 102 条里 JA 92 / Review 70 / 同时 64；独立相加 162 > 102 |
| `synonym` 默认 true 差数倍 | **未复现，不采纳** | 缺省 / `true` / `false` 三种设置命中数完全相同（6,544 与 220,864 各自不变）。改写为「开关无差异，别拿它解释命中数」 |
| `Review` 与叠加后命中相同 | **未复现，不采纳** | 70 vs 64 |

### 3. 六类改优先级归类

`pubType` 多标签叠加（见上表实测），独立分类查询相加必然重复计数，改为每条只落一类 + 断言和为总数，由 `ledger.py classify` 机检。

### 4. 反事实核查改独立时间窗

反向检索不再套本周 7 天窗，要求至少覆盖 5 年，并写明式子、时间范围、命中数。原设计下更早、更大的相左证据会被结构性排除，「已检索，未见相左证据」变成设计保证的结论。

### 5. 反馈机制（本地分支并入）

- 新增 `FEEDBACK.md`：五类反馈（A 检索式 / B 交付门误判 / C 部署失败 / D 判断有误 / E 文档与实现不一致）、标题格式、正文六项、三类别发。
- 主提示词新增「出问题时：把反馈渠道和模板交给用户」，六个触发点主动给可复制块，并禁止因「可能要反馈」中断交付。
- `plugin.json` 记 `author.email`。**不承诺响应时限**——个人维护，写死天数等于给自己挖坑。

### 6. `bin/setup.py` 四项已知缺陷修复（原列在 v1.2.0「未做」里）

| 缺陷 | 现象 | 修法 | 实测 |
|---|---|---|---|
| 假就绪 | dist 元数据在 + 配置在 + 启动入口缺失 → 仍 `ok:true` | `installed` 改以「能否启动」判定；元数据在但找不到入口 → 明确报「多半装进了另一个 Python」并判不 ready | — |
| dry-run 真装 | `--install --dry-run` 照样跑 pip | dry-run 分支直接跳过安装，只报「将做什么」 | 配置 hash 前后一致，pip 未触发 |
| 不读既有配置 | `resolve_launcher` 无视 mcp.json 里能跑的命令，硬改成当前解释器 | 优先信任已有配置（绝对路径存在、或 PATH 可解析的命令） | launcher 由 `console-script` 变为 `existing-config` |
| 整条替换 | 同名 server 被覆盖，用户自加的 `timeout` / `env` 丢失 | 改为字段级合并：保留其它键，`env` 以用户值优先 | 用户 `timeout=30`、`MY_VAR`、`PYTHONIOENCODING=gbk` 全部保留，仅补默认键 |
| 握手太松 | 只认 `serverInfo.name`，不校验 `jsonrpc` / `id` / `protocolVersion` | 三者齐备才算通过 | 两个服务仍握手成功 |

顺带：`--print-config` 现在也读既有配置，预览与实际写入一致（此前会误报「更新」）。

### 7. 事实更正（含作者自己的错）

- `med-lit-mcp` 在 PyPI 确有公开版本（0.3.0，非商业许可），此前「未查到公开安装源」不成立。
- 通用正则误伤率：原写「61%」，2026-11-03 抽样 50 条实测 20%（10 条，吞的是 `<0.001` 与 `<h4>`）。


## v1.2.0（2026-11-03）

针对审阅结论「规约承诺 ≠ 可执行机制」做三项改造，验收标准是**可机检**，不是自我声明。

### 1. 新增 `bin/ledger.py`：把「交付门」从模型自证变成退出码

- 新子命令 `check`：对**周报正文**做十二项机检（锚定结构、锚定与摘要快照一致、报告绑定、未登记数字、无 EDAT、检索式一致性、六类加总、反证节、无摘要单列、引用编号、精读条目锚定、取数与 hitCount 对账）。
  - 任一项不过 → `exit 1`；文件/JSON 本身有问题 → `exit 2`；`--json` 输出 `failed` 项列表。
  - 省略 `--classes` / `--ledger` 不再视为「跳过」，直接判失败——防止靠少传参数过检。
- 新子命令 `make`：生成单条锚定记录（`{pmid, quote, hash12, found}`），PMID 不在快照里直接失败，取消 `anchor.py` 的「只有一条源就拿来兜底」。
- 新子命令 `classify`：按优先级 `勘误 > 预印本 > 述评 > 综述 > 无摘要 > 研究` 给每条记录只落一类，断言六类之和 == 总数，并输出 `mesh_coverage`（MeSH 覆盖率）。
- 顺带修掉 `anchor.py` 的四个已知缺陷：
  1. 跨段拼接（`<p>hello</p><p>world</p>` + 「hello world」）——改为按标签分段后逐段匹配，跨段直接失败；
  2. 摘录缺 `hash12`、空锚定表（0/0）——一律判失败，不再静默放行；
  3. `U+2212` 等字符在 GBK 控制台 `UnicodeEncodeError` 崩 —— 启动时对 stdout/stderr `reconfigure(utf-8)`；
  4. 错误的 PMID 靠单源兜底通过 —— 已删除该 fallback。
- 附带测试：`tests/test_ledger.py`（在仓库的 workspace 侧，不随专家包分发），13 条验收用例（改数字、删哈希、空锚定、跨段拼接、未登记数字、式子不一致、六类加总、删反证节、GBK 不崩、缺 PMID、省略参数、多标签分类），全部通过。\n- **对作者自己那份 `心衰文献周报_2026-11-02.md` 实测：12 项里 7 项不过**（锚定表为空、未登记数字、无检索式账本、无反证节、无摘要未单列、`#NN` 编号在附录查不到、精读条目无 hash12）——这正是「没有裁决者时规约必然落空」的现场证据。

### 2. 日期与检索口径按实测修正

- 删除「窗口起点多给一天 / 要 7 天写 `NOW-8DAYS`」。实测 `[NOW-7DAYS TO NOW]` 等于显式 7 天窗（逐条 ID 相同，只是不含当天），写 `NOW-8DAYS` 会让每周窗口与上期重叠一天、同篇连续两周上榜。
- 对账从「三次 hitCount 相加」改为 `resultType=idlist&pageSize=1000` 拉 ID 集合，验 `|A∪B| = |A|+|B|−|A∩B|`；差额超 `max(2, 0.5%)` 停并落 `mismatch.json`。
- 补充 `synonym` 默认 `true` 的扩展风险（显式声明或关闭）、`sort` 必须带方向（`P_PDATE_D desc`）、`pageSize` 接口硬上限 1000。
- 明确 `MESH` 在最近入库记录里缺失率高（近 7 天约 46%、近 13 天约 72%），只能作辅助分支，不能当主概念分支。
- 明确接口只回显 `queryString`、没有解析树 / `queryTranslation`，式子怎么被解释只能靠分项对账自证。

### 3. 六类分流改为优先级归类

- `pubType` 是多标签叠加（实测 `PUB_TYPE:"Review"` 与再叠加 `PUB_TYPE:"Journal Article"` 命中数完全相同），六类独立查询相加必然重复计数、永远凑不出总数。
- 改为「每条只落一类」的优先级归类，并由 `ledger.py classify` 断言六类之和 == 命中总数。

### 4. 反事实核查改为独立时间窗

- 反向检索不再套用本周 7 天窗，要求至少覆盖 5 年，并在报告第 3 节写明「式子、时间范围、命中数、有无相左证据」。原设计下相左证据（更早、更大、质量更高）会被结构性排除，「已检索，未见相左证据」成为设计保证的结论。

### 5. 文档与元数据同步

- `README.md`：方法表、功能清单、技术要点、锚定工具章节重写为 `ledger.py` 交付门；新增「版本与变更（v1.2.0）」。
- `README.md` 更正事实错误：`med-lit-mcp` **确有公开版本**（PyPI 0.3.0，PolyForm Noncommercial 1.0.0），原文「未查到公开安装源」不成立；因其许可为限制性非商业许可且定位重叠，仍未纳入默认部署。
- `plugin.json`：`version` → `1.2.0`；`description` 去掉「依赖 MeSH 词表」的过强表述，补「交付门由机器检查、非零退出即拒绝出稿」。

### 未做（留给下一版）

- `setup.py` 的 `--dry-run` 仍会真的 pip 装包（应 gate 掉）；`resolve_launcher` 不读既有 `mcp.json`，会把已可用配置误判为「未安装」；`--check` 的「假就绪」判定；握手不校验 `jsonrpc`/`protocolVersion`；pip 裸包名无版本钉与哈希；同名 server 整条替换会覆盖用户既有字段。
- `anchor.py` 的 NFKC 数字碰撞（`10⁶` ≡ `106`）、`offset` 实为归一化偏移、无批量 `make`。
- 跨周状态（上期 topics / 已读 PMID）、`--refetch` 回源取证、评测集与误报率基准、`maxTurns` 预算与批量锚定。
