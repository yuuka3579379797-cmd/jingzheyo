# 接到别的 AI 里跑（可移植性说明）

**结论先说：能跑，但要分清「跑到哪一层」。** 这个包不是一段提示词，也不是一个死绑在 WorkBuddy 上的插件，它是三层可以拆开用的东西。拆开之后，能力上限由你给的壳子决定，不由模型决定。

## 一、三层，各管一段

| 层 | 文件 | 管什么 | 换客户端的代价 |
|---|---|---|---|
| **提示词层** | `agents/medical-lit-radar.md`（正文）+ `prompts/feedback_guidance.md` | 方法、边界、九条铁律、周报模板、判断口径 | 0。纯文本，任何模型都读得懂 |
| **脚本层** | `bin/*.py` | 检索窗口、锚定、交付门、MCP 部署 | 需要 Python 3.10+ 和能执行命令的环境 |
| **MCP 层**（可选） | `literature-evidence` / `tekmeria` | 段落级锚定、撤稿查询、全文段落 ID | 标准 stdio MCP，支持 MCP 的客户端都能挂 |

关键点：**交付质量的兜底在脚本层，不在模型层。** 换成 GPT、Claude、DeepSeek、Qwen 或本地 70B，只要还能跑 `bin/ledger.py check`，报告就不会因为模型换了而变成一堆没出处的数字。

## 二、能力矩阵

| 客户端 | 提示词 | 跑脚本 | MCP | 能出真周报？ |
|---|---|---|---|---|
| **WorkBuddy 专家中心** | ✅ 原生 | ✅ | ✅ | ✅ 完整体验 |
| **Claude Code** | ✅ `CLAUDE.md` 或 subagent | ✅ | ✅ `claude mcp add` | ✅ 完整体验 |
| **Cursor / Windsurf** | ✅ rules 或 `AGENTS.md` | ✅ 终端 | ✅ `.cursor/mcp.json` | ✅ 完整体验 |
| **Cline / Roo 等 VS Code 插件** | ✅ 自定义指令 | ✅ | ✅ 一般支持 | ✅ |
| **OpenAI / DeepSeek / 通义 API** | ✅ system message | ⚠️ 要自己接工具调用 | ⚠️ 要自己实现 | ⚠️ 能做，但要写工具桥 |
| **Ollama / LM Studio 本地模型** | ✅ | ⚠️ 同上 | ❌ 多数不支持 | ⚠️ 32B 以下判断质量明显下滑 |
| **网页版 ChatGPT / Claude / Gemini** | ✅ 粘贴 | ❌ 不能跑命令 | ❌ | ❌ 只能出检索式与判断框架，**不能出带数字的周报** |

最后一行要特别当真：**没有 shell 就没有全量与对账**。这种情况下它会退化成「帮你把检索式拼好、把判断框架讲清」，数字必须由你在本机跑出来再回填。任何声称「网页版也能出完整周报」的说法，都是在编 hitCount。

## 三、怎么导出提示词

```bash
# 1. 看体积（决定你的模型上下文够不够）
python3 bin/export_prompt.py --check
#   字符数 21266 ｜ 估算 token 1.3 万–1.9 万 ｜ 建议上下文 ≥ 64k

# 2. 导出成一段 markdown（粘到任何客户端的 system prompt / rules 里）
python3 bin/export_prompt.py --out yomlia-system.md

# 3. 导出成 OpenAI 风格 payload（API 直接发）
python3 bin/export_prompt.py --format json --model deepseek-chat --out system.json

# 4. 想要更瘦的版本（去掉运行环境说明与隐私附录，约 1.1 万 token）
python3 bin/export_prompt.py --no-runtime --no-guidance --out slim.md
```

导出时会做三件事：剥掉 WorkBuddy 的 frontmatter（`name` / `displayName` / `maxTurns` 这些别的客户端不认）、补一段**运行环境说明**（告诉模型自己有没有 shell、没有时该怎么降级）、附上反馈与隐私策略附录。

## 四、四种常见接法

### 1. Claude Code

```bash
# 把包放到工作目录，提示词做成项目指令
python3 bin/export_prompt.py --out CLAUDE.md

# 需要段落级核验时再挂 MCP（可选）
claude mcp add literature-evidence -- /path/to/literature-evidence-mcp
claude mcp add tekmeria -- /path/to/tekmeria
```

想让它只在一个子任务里生效，就写成 `.claude/agents/yomlia.md`，把导出的内容放进正文、frontmatter 补 `name` 与 `description`。

### 2. Cursor / Windsurf

- 提示词：`.cursor/rules/yomlia.mdc`（或项目根的 `AGENTS.md`），内容用导出结果
- MCP：项目根建 `.cursor/mcp.json`

```json
{
  "mcpServers": {
    "literature-evidence": {
      "command": "literature-evidence-mcp",
      "args": [],
      "env": { "PYTHONIOENCODING": "utf-8" }
    },
    "tekmeria": {
      "command": "tekmeria",
      "args": [],
      "env": { "PYTHONIOENCODING": "utf-8" }
    }
  }
}
```

Windows 上 `command` 建议写绝对路径（`.workbuddy/binaries/python/versions/.../Scripts/literature-evidence-mcp.exe`），否则 GUI 启动的客户端可能找不到 PATH。

### 3. API（OpenAI / DeepSeek / 通义 / 自建）

```bash
python3 bin/export_prompt.py --format json --model deepseek-chat --out system.json
```

拿 `system.json` 里的 `messages` 直接发。模型要能调工具（function calling），你需要在服务端把 `bin/window.py`、`bin/ledger.py` 包成函数暴露出去——**这是接 API 唯一麻烦的地方，也是唯一值钱的地方**：把交付门挂上去，模型换了也不影响可核验性。

### 4. 网页版聊天（只能做一半）

把导出的 `slim.md` 粘进「自定义指令 / Project instructions」，然后：

- ✅ 能拿到：检索式怎么拆、MeSH 怎么选、结果怎么对账、报告该长什么样
- ❌ 拿不到：真实 hitCount、真实 PMID、真实摘要、哈希锚定、交付门机检
- ⚠️ 它可能会「顺着你的话编数字」。开工前先跟它说一句：**「没有联网就直说没有，数字我自己回填」**

## 五、换模型后最先退化的三件事

1. **窗口纪律**：小模型容易把 `FIRST_PDATE:[2026-10-27 TO 2026-11-02]` 简写成 `NOW-7DAYS`。对策：`bin/ledger.py check` 的 `query_consistency` 会比对报告里的式子与 `ledger.json`，不一致直接拒收。
2. **引用纪律**：模型会「记得」一个 PMID 然后写上去。对策：`bin/anchor.py verify --sources abstracts.json` 要求逐字命中，编的句子在原文里找不到就报错。
3. **格式纪律**：六类分区、账目表、附录容易被压缩掉。对策：交付门的 12 项检查是结构化的，缺节就 FAIL，不靠模型自觉。

这三条正是「模型可换、标准不换」的原因：**标准写在脚本里，不写在模型的脾气里。**

## 六、自测清单（接到新客户端后跑一遍）

```bash
# 1. 环境自检（不写日志、不改配置）
bash bin/bootstrap.sh --check --json

# 2. 交付门正例：合成数据应当 12/12 通过
python3 bin/ledger.py check \
  --report tests/fixtures/report.sample.md \
  --abstracts tests/fixtures/abstracts.sample.json \
  --anchors tests/fixtures/anchors.sample.json \
  --classes tests/fixtures/classes.sample.json \
  --ledger tests/fixtures/ledger.sample.json

# 3. 负例：故意改一位哈希，应当 FAIL
```

然后在新客户端里问它三个问题，答对说明提示词生效了：

1. 窗口用 `NOW-7DAYS` 还是显式日历日？为什么？
2. 报告里出现一个锚定表上没有的数字，交付门会怎么处理？
3. 没有 shell 的时候，你能不能出「本周新增 42 条」这种结论？

标准答案：显式日历日（滚动窗切起始日）；拒绝交付并点名；不能，只能给检索式和框架。

## 七、兼容性备注

> 装法（拖给 AI / 手动 / 各平台差异）见 [`deploy.md`](deploy.md)，本文只讲「装好之后怎么能跑对」。

- **上下文**：完整版约 1.3–1.9 万 token，建议 ≥ 64k。8k 上下文的模型请用 `--no-runtime --no-guidance`，并接受判断质量下降。
- **语言**：提示词是中文，输出也是中文。要用英文周报，需要改模板节标题与判断句式，不是加一句「请用英文」就行。
- **工具协议**：MCP 层是标准 stdio JSON-RPC，与客户端无关；脚本层是纯标准库 Python，不依赖 WorkBuddy 的任何 SDK。
- **不支持**：图像输入、PDF 全文解析、中文数据库（CNKI/万方）。这三样换哪个模型都不会有。
