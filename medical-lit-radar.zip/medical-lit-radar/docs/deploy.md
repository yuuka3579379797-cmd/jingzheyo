# 怎么装（三种，按省事程度排）

这个包没有安装程序，也不需要。**它就是一个文件夹**，里面是提示词、几个 Python 脚本、一张头像。所谓「安装」，就是把它放到对的位置、让宿主认得它。

## 一、最省事：把包拖给 AI，让它装

把 `medical-lit-radar.zip` 拖进对话框（或解压后把文件夹拖进去、或把路径发过去），然后贴上下面这段。**任何有文件权限的 Agent 都能照做**：

```text
这是一个 WorkBuddy 专家包（显示名 YoMLIA），请你帮我装好，不要跳步骤：

1. 找到包根目录——有 .codebuddy-plugin/plugin.json 的那一层。
2. 复制到专家目录：~/.workbuddy/plugins/marketplaces/my-experts/plugins/medical-lit-radar/
   （Windows 为 C:\Users\<你>\.workbuddy\plugins\marketplaces\my-experts\plugins\medical-lit-radar\）
   已存在就先备份成 medical-lit-radar.bak-<日期> 再覆盖。
3. 到 WorkBuddy 安装目录下找这几个脚本：
   resources/app.asar.unpacked/resources/plugins/workbuddy-builtin/skills/expert-manager/scripts/
   先跑 validate_expert.py <专家目录>，再跑 register_expert.py <专家目录>。
4. 把两条命令的完整输出贴给我，并告诉我需要做什么（通常是重启 WorkBuddy）。

注意：validate 不通过就停下，把报错原文给我，不要跳过校验直接注册。
```

它装完会告诉你「重启一下」。重启后进【专家中心 → 我的专家】，看到 **YoMLIA** 与橘发拿书的头像就算成了。

**为什么要跑校验**：专家目录有硬性结构要求（`plugin.json` 字段、`agents/` 下的 md、头像尺寸），`validate_expert.py` 是唯一能提前发现问题的东西。跳过它直接注册，常见结果是「列表里有名字，点进去打不开」。

## 二、没有专家中心：把它当系统提示词 + 工作目录

DeepSeek Harness、千问 Code、Claude Code、Cursor 这类工具没有 WorkBuddy 的专家中心，装法不一样——**不用「注册」，用「设提示词 + 放脚本」**：

```text
这个目录是一个医学文献追踪 Agent 的包，请按下面做：

1. 用 python3 bin/export_prompt.py --out yomlia-system.md 导出系统提示词，
   把它的内容设为你的系统提示词（或项目规则 / AGENTS.md / CLAUDE.md）。
2. 把 bin/ 保留在工作目录里，后面需要执行：
   - python3 bin/window.py dates --days 7      算检索窗口
   - python3 bin/ledger.py check ...           交付前机检（12 项）
3. 现在用一句话复述：你的检索窗口用 NOW-7DAYS 还是显式日历日？为什么？
   以及没有 shell 时该怎么降级。
```

第三句是验收：答不出「显式日历日，因为 NOW-7DAYS 是滚动窗会切掉起始日」，说明提示词没生效。

各客户端的细节（MCP 配置、能力矩阵、换模型后先退化什么）见 [`portability.md`](portability.md)。

## 三、只有网页版聊天窗：只用得上提示词

网页版 ChatGPT / Claude / 千问 **不能执行命令**，所以：

```bash
python3 bin/export_prompt.py --no-runtime --no-guidance --out slim.md   # 约 1.1 万 token
```

把 `slim.md` 粘进「自定义指令 / Project instructions」。它能把检索式拼好、把判断框架讲清，**但出不了带数字的周报**——没有 shell 就没有全量命中、没有对账、没有哈希锚定。任何张口就来「本周新增 42 条」的回答，42 都是编的。

## 四、手动三步（不想让 AI 碰文件时）

```bash
# 1. 放到位
mkdir -p ~/.workbuddy/plugins/marketplaces/my-experts/plugins
cp -r medical-lit-radar ~/.workbuddy/plugins/marketplaces/my-experts/plugins/

# 2. 校验（不通过别继续）
python3 <WorkBuddy>/resources/app.asar.unpacked/resources/plugins/workbuddy-builtin/skills/expert-manager/scripts/validate_expert.py \
  ~/.workbuddy/plugins/marketplaces/my-experts/plugins/medical-lit-radar

# 3. 注册
python3 <WorkBuddy>/resources/app.asar.unpacked/resources/plugins/workbuddy-builtin/skills/expert-manager/scripts/register_expert.py \
  ~/.workbuddy/plugins/marketplaces/my-experts/plugins/medical-lit-radar
```

三条都可能踩的坑：

| 现象 | 原因 | 怎么办 |
|---|---|---|
| `专家不在专家目录下，将无法被检测到` | 包放在了桌面或别处 | 挪到 `.../marketplaces/<市场名>/plugins/` 下再校验 |
| 列表里有 YoMLIA，点进去空白 | 没重启，或 `avatar` 指向不存在的文件 | 重启；确认 `plugin.json` 的 `avatar` 与实际文件名一致 |
| 头像还是旧的 | 面板按路径缓存图片 | 换文件名（`expert-v4.png`）并同步 `plugin.json` |

## 五、装好之后的三条验收

```bash
# 1. 依赖体检（MCP 缺失也算「部分可用」，不是失败）
bash bin/bootstrap.sh --check --json

# 2. 交付门正例：合成数据应当 12/12 通过
python3 bin/ledger.py check \
  --report tests/fixtures/report.sample.md \
  --abstracts tests/fixtures/abstracts.sample.json \
  --anchors tests/fixtures/anchors.sample.json \
  --classes tests/fixtures/classes.sample.json \
  --ledger tests/fixtures/ledger.sample.json

# 3. 窗口验证（需要联网）：三窗计数应当明显不同
python3 bin/window.py verify --topic '(MESH:"Heart Failure")' --days 7
```

第 2 条通过、第 3 条能跑出数，说明脚本层是活的。剩下的就是第一次对话时让它做自我介绍，听它有没有把「不做什么」和「数据存哪」说出来。
