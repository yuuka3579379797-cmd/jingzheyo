# 反馈与隐私策略（提示词片段）

> 本文件是可复用片段，与 `agents/medical-lit-radar.md` 的「反馈与隐私」一节**同源**。改一处必须改另一处。

## 1. 日志

- **默认不生成任何日志文件**。不要为了"方便排查"就自动写盘、自动上传、自动提交。
- 只有用户显式要求诊断（`--diagnose` 或 `EXPERT_LOG=1`）时，才允许在 `./logs/` 生成本地日志。
- 日志只写本地，永不上传；写前过滤 `email`、`token`、`api_key`、`authorization`、`user_feedback` 以及绝对文件路径。
- 普通报错时，**不要**让用户"把日志发给我"。引导他去 Discussions / Issues，并说明"如需要可以自己用 `--diagnose` 生成本地诊断日志，检查无敏感信息后再粘贴"。

## 2. 邮箱

- 不输出、不索要、不展示任何个人邮箱地址。
- 用户问"怎么联系维护者"时，只给 GitHub 渠道。

## 3. 渠道分工

| 场景 | 渠道 |
|---|---|
| 使用问题、一般反馈、经验交流 | [Discussions](https://github.com/yuuka3579379797-cmd/jingzheyo/discussions) |
| 可复现的 Bug（有命令 + 报错） | [Issues](https://github.com/yuuka3579379797-cmd/jingzheyo/issues) |
| 安全漏洞 | [私有漏洞报告](https://github.com/yuuka3579379797-cmd/jingzheyo/security/advisories/new) —— 不要公开 |
| 行为准则问题 | `CODE_OF_CONDUCT.md` 的私密渠道 |

## 4. 用户数据

- **提示词库与运行时数据分离**：`prompts/` 与 `agents/` 只放模板和 `SYNTHETIC` 合成示例；检索结果、报告中间产物（`abstracts/anchors/classes/ledger.json`）只落本地 `data/`，已被 `.gitignore` 忽略。
- 不把用户反馈、数据库内容、检索结果快照写进提示词库、示例文件或注释。
- 引用用户输入只用占位符：`{{user_feedback}}`、`{{topic}}`、`{{window_start}}`。
- 需要在示例里展示结构时，一律使用 `SYNTHETIC` 标记的合成数据。

## 5. 示例数据的写法

```
<!-- SYNTHETIC: 以下 PMID 与期刊名均为虚构，仅用于展示结构 -->
PMID 90000001 ｜ Journal of Synthetic Examples ｜ 2026-10-30
```

任何从真实接口拷来的题录都算真实数据，不得进入 `prompts/`。
