# 反馈 · YoMLIA

**本项目不提供邮箱反馈，也不收集任何用户数据。**

所有反馈走 GitHub，按用途分开，便于后来的人检索到同样的答案：

| 你想做的事 | 渠道 |
|---|---|
| 使用问题、检索式怎么拼、经验交流、一般反馈 | [Discussions](https://github.com/yuuka3579379797-cmd/jingzheyo/discussions) |
| 可复现的 Bug（有命令、有报错） | [Issues](https://github.com/yuuka3579379797-cmd/jingzheyo/issues) |
| 安全漏洞 | [私有漏洞报告](https://github.com/yuuka3579379797-cmd/jingzheyo/security/advisories/new) —— **不要开公开 Issue** |
| 行为准则问题 | 见 `CODE_OF_CONDUCT.md` 的私密渠道 |

> 以上链接指向 https://github.com/yuuka3579379797-cmd/jingzheyo 。仓库若迁移，上面这些链接（连同主提示词、`README`、`CONTRIBUTING`、`SECURITY`、`CODE_OF_CONDUCT`、`config.example.env`、`prompts/feedback_guidance.md`）要一起改。

---

## 一、什么值得反馈（五类，按有用程度排序）

| 类型 | 典型情况 | 能做什么 |
|---|---|---|
| **A 检索式** | 逐分支带显式窗口后，ID 集合对账差额仍超 `max(2, 0.5%)`；明显该命中的没命中 | 一起重拼式子，或收进「领域检索式库」 |
| **B 交付门误判** | `ledger.py check` 报某项失败但核对后没问题（误报）；或明明有问题却 `exit 0`（漏报） | 误报改检查项，漏报加检查项——这两类最有价值 |
| **C 部署失败** | `bootstrap.sh --install` 报 `failures`；握手不通；装完工具没挂上 | 给 `--check --json` 输出即可定位 |
| **D 判断有误** | 某篇的「一句话判断」站不住；漏了高相关文献；反证节写「未见」但你知道有不一致研究 | 改提示词里的判断纪律 |
| **E 文档与实现不一致** | 文档写的命令、参数、数字，实际跑出来不是那样 | 改文档或改实现，必须对齐 |

**不建议反馈**：「能不能做全文精读」「能不能查中文文献」「能不能写综述」——设计上明确不做，理由见 README。

---

## 二、Issue 格式

标题：

```
[YoMLIA][A/B/C/D/E] 一句话现象
例：[YoMLIA][A] 逐分支带窗口后差额 23 条
例：[YoMLIA][E] NOW-7DAYS 与显式 7 天窗不等价
```

正文六项，A/B 类前三项必填：

```
1. 版本        1.5.0（照抄 plugin.json 的 version；本文示例可能滞后）
2. 环境        系统 ｜ Python 版本 ｜ MCP 是否装上（bash bin/bootstrap.sh --check --json 的首行结论）
3. 任务        研究方向 ｜ 窗口起止日 ｜ 完整检索式（原样）
4. 现象        预期 vs 实际，一句话
5. 证据        check 的 failed 项 JSON / 报错原文 / 锚定表相关几行 / 相关 PMID
6. 复现        跑了哪条命令
```

证据怎么给最省事：

- **A 类**：三个分支的式子 + 各自 `hitCount` + `|A∪B|`，加窗口起止日；有 `mismatch.json` 直接附。
- **B 类**：`ledger.py check --json` 的完整输出（`items[].detail` 就是判断依据）。
- **C 类**：`bash bin/bootstrap.sh --check --json` 的完整输出（不含隐私，可直接贴）。
- **D 类**：PMID + 一句你认为错在哪，不用贴整份周报。
- **E 类**：文档原文 + 你实际得到的输出。

---

## 三、三条不要发的东西

1. **患者信息 / 未发表数据**：先脱敏；涉及伦理审查材料不要公开。
2. **整篇全文 PDF / 出版社排版文件**：版权上不能收，摘要片段足够定位。
3. **真实 API key / 密码 / 机构内网地址**：贴 JSON 输出时留意 `env` 字段。

---

## 四、关于日志

**默认不生成任何日志文件。** 需要排查时，自己运行：

```bash
bash bin/bootstrap.sh --check --diagnose
```

日志写到 `data/logs/setup.log`，写前已把用户主目录替换为 `[HOME]`。**贴之前请自己再看一遍**——如果里面出现你的单位、内网地址或任何你不想公开的内容，删掉再贴。本项目不会主动索要日志。

---

## 五、修好之后怎么更新

```bash
# 1) 用新版覆盖目录（自己加的检索式笔记先另存）
~/.workbuddy/plugins/marketplaces/my-experts/plugins/medical-lit-radar/

# 2) 重新注册
python3 <WorkBuddy安装目录>/resources/plugins/workbuddy-builtin/skills/expert-manager/scripts/register_expert.py <expert-dir>

# 3) 重启 WorkBuddy
```

本地 MCP 配置不用动：`bin/setup.py` 幂等，覆盖后下次调用会自己核对一遍，已装则零变更。

---

## 六、许可提醒

本包采用 [CC BY-NC-SA 4.0](LICENSE)：可自由复制、修改、再分发，须署名、不得商用、修改后须同协议共享。
`avatars/expert-v3.png` 由作者用 AI 绘图生成，随本包一同按上述协议授权，署名「惊蛰yo」即可；商用前请自行确认你所在辖区对 AI 生成内容的规定。
