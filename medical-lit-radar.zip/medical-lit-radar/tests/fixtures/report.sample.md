<!-- SYNTHETIC：本文所有 PMID、期刊、数字均为虚构，用于演示交付门 -->
# 合成样例 · 糖尿病肾病标志物周报（2026-10-27 → 2026-11-02）

## 0. 一句话结论

本期共 3 条合成记录，其中 2 条可用于演示锚定流程，1 条无摘要待回填。

## 1. 账目表

检索式（原样贴出）：(TITLE_ABS:diabet* AND TITLE_ABS:kidney) AND (TITLE_ABS:biomarker* OR TITLE_ABS:marker*) AND FIRST_PDATE:[2026-10-27 TO 2026-11-02]
总命中 3 条（窗口 2026-10-27 → 2026-11-02，7 个完整日历日，未使用滚动窗）
分类计数（优先级归类）：研究 2 / 综述 1 / 述评 0 / 勘误 0 / 预印本 0 / 无摘要 0
（六类相加 = 3，等于总数）

## 2. 值得精读的 2 篇

### 1) Synthetic trial of compound X in diabetic kidney disease
- PMID 90000001 ｜ Journal of Synthetic Examples ｜ 研究
- 核心结果：compound X reduced the primary composite endpoint (HR 0.72; 95% CI 0.61-0.85; P<0.001)
- 原文锚定：`hash12=7703aeea15de` ｜ 原句「compound X reduced the primary composite endpoint (HR 0.72; 95% CI 0.61-0.85; P<0.001)」
- 一句话判断：合成数据，仅用于演示；真实场景下这里写"改变了什么"。
- 对你的课题：可引用点 / 需警惕的局限。

### 2) Synthetic review of urinary marker Y
- PMID 90000002 ｜ Journal of Synthetic Examples ｜ 综述
- 核心结果：urinary marker Y was associated with faster eGFR decline (beta -0.83 mL/min per year; 95% CI -1.21 to -0.45)
- 原文锚定：`hash12=aad73fecf578` ｜ 原句「urinary marker Y was associated with faster eGFR decline (beta -0.83 mL/min per year; 95% CI -1.21 to -0.45)」
- 一句话判断：合成数据，仅用于演示。
- 对你的课题：合成数据，仅用于演示。

## 3. 反向证据核查（L7.5）

- 待检验的核心主张：compound X 降低复合终点
- 反向检索式（原样）：(TITLE_ABS:compound X AND TITLE_ABS:kidney) AND FIRST_PDATE:[2021-01-01 TO 2026-11-02]
- 命中 0 条（窗口覆盖 5 年）
- 结论：已检索反向证据，未见相左的高质量研究（合成样例，无实际检索）

## 4. 综述与指南变动

1 篇合成综述已收录（PMID 90000002），用于演示归类优先级。

## 5. 勘误与撤稿

本期无（合成样例）。

## 6. 预印本雷达

本期无（合成样例）；真实场景下需标注「未经同行评议」并给 DOI。

## 7. 下周建议追的检索式

(TITLE_ABS:diabet* AND TITLE_ABS:kidney) AND (TITLE_ABS:biomarker* OR TITLE_ABS:marker*) AND FIRST_PDATE:[2026-11-03 TO 2026-11-09]

## 附录 A：数字锚定表

| # | PMID | 关键数字 | 原文摘录（逐字） | hash12 | 核验 |
|---|------|---------|-----------------|--------|------|
| 1 | 90000001 | HR 0.72 | compound X reduced the primary composite endpoint (HR 0.72; 95% CI 0.61-0.85; P<0.001) | 7703aeea15de | ✅ |
| 2 | 90000002 | beta -0.83 | urinary marker Y was associated with faster eGFR decline (beta -0.83 mL/min per year; 95% CI -1.21 to -0.45) | aad73fecf578 | ✅ |

## 附录 B：全量清单

| # | PMID/DOI | 标题 | 期刊 | 发表日期 | 类型 | 有无摘要 |
|---|----------|------|------|---------|------|---------|
| 1 | 90000001 | Synthetic trial of compound X | Journal of Synthetic Examples | 2026-10-29 | 研究 | 有 |
| 2 | 90000002 | Synthetic review of marker Y | Journal of Synthetic Examples | 2026-10-31 | 综述 | 有 |
| 3 | 90000003 | Synthetic record without abstract | Journal of Synthetic Examples | 2026-11-01 | 研究 | 无（待回填） |

无摘要条目（待回填）：PMID 90000003
