# 测试样例说明 · SYNTHETIC

**本目录所有数据均为合成，不含任何真实文献。**

- PMID `90000001` / `90000002` / `90000003` 是虚构编号（不存在的号段）；
- 期刊名 `Journal of Synthetic Examples` 是虚构的；
- 摘要文本由人工构造，`HR 0.72`、`beta -0.83` 等数字只用于演示锚定格式；
- `report.sample.md` 是一份**能通过交付门**的最小周报，用来做回归基线。

## 为什么要有这套样例

`bin/ledger.py check` 的十二项检查如果只有"失败"的案例（比如作者那份真实周报有 7 项不过），就无法区分"检查太严"和"输入确实不合格"。需要一份**应当通过**的输入来锚定这条线：

```
交付门：PASS（12 项，失败 0）
```

## 怎么跑

```bash
python3 bin/ledger.py check --report tests/fixtures/report.sample.md \
  --abstracts tests/fixtures/abstracts.sample.json \
  --anchors   tests/fixtures/anchors.sample.json \
  --classes   tests/fixtures/classes.sample.json \
  --ledger    tests/fixtures/ledger.sample.json
```

期望：退出码 `0`，十二项全绿。

把 `anchors.sample.json` 里某个 `hash12` 改一位、或把报告里的 `HR 0.72` 改成 `HR 0.62`，应当立刻变成 `exit 1` 并点名对应检查项——这两条是"门真的会拦"的最小证据。

## 文件

| 文件 | 内容 |
|---|---|
| `abstracts.sample.json` | `{pmid: 摘要}` 快照，含一条空摘要（演示"无摘要待回填"） |
| `results.sample.json` | Europe PMC 风格响应，含多标签 `pubType`（演示优先级归类） |
| `anchors.sample.json` | 两条锚定记录（`hash12` 由 `ledger.py make` 实算） |
| `classes.sample.json` | 六类归类结果（`ledger.py classify` 生成） |
| `ledger.sample.json` | 检索账本（式子、窗口、hitCount / returned） |
| `report.sample.md` | 可通过交付门的最小周报 |
