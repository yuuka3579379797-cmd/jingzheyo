# 参与贡献 · YoMLIA

先看渠道分工。**发错地方最容易被忽略**，尤其是把安全漏洞发到公开 Issue。

## 一、该发到哪里

| 你想做的事 | 渠道 |
|---|---|
| 使用问题、检索式怎么拼、经验交流、一般反馈 | [GitHub Discussions](https://github.com/yuuka3579379797-cmd/jingzheyo/discussions) |
| 可复现的 Bug（有命令、有报错、有输入） | [GitHub Issues](https://github.com/yuuka3579379797-cmd/jingzheyo/issues) |
| 功能建议 | Discussions 优先；已经想清楚要改哪几行就直接开 Issue |
| 安全漏洞 | [GitHub 私有漏洞报告](https://github.com/yuuka3579379797-cmd/jingzheyo/security/advisories/new) —— **不要开公开 Issue** |
| 行为准则问题 | 见 `CODE_OF_CONDUCT.md` 的私密渠道 |

本仓库**不提供邮箱反馈**，也不要求任何人提交日志。所有沟通留在 GitHub 上，便于后来的人检索到同样的答案。

## 二、改提示词的规矩

本包的"系统提示词"就是 `agents/medical-lit-radar.md`——它是唯一生效的提示词，`prompts/` 里只是可复用的片段。改的时候注意三件事：

1. **一处事实，两处同步**：反馈渠道与隐私策略同时写在 `agents/medical-lit-radar.md` 和 `prompts/feedback_guidance.md`，改一处必须改另一处。
2. **不写不可验证的数字**：任何"实测 X 条 / 差 Y 倍"的断言，必须在 PR 描述里给出复现命令与测量时间。写不出复现步骤的，改成定性描述。
3. **不把用户数据写进提示词**：示例、fixtures、注释里只能用合成或脱敏数据（见下节）。

## 三、测试数据必须合成或脱敏

- 允许：假 PMID（`90000001` 这类不存在的号）、假期刊名、AI 生成的摘要文本，且文件头注明 `SYNTHETIC`。
- 禁止：真实患者信息、未发表稿件、真实检索结果快照、带邮箱/机构内网地址的题录。
- 位置：只放 `tests/fixtures/`，不要放 `prompts/` 或包根目录。`prompts/` 里出现任何真实数据都按泄漏处理。

`tests/fixtures/` 现成的样例可以直接跑：

```bash
python3 bin/ledger.py check --report tests/fixtures/report.sample.md \
  --abstracts tests/fixtures/abstracts.sample.json \
  --anchors tests/fixtures/anchors.sample.json \
  --classes tests/fixtures/classes.sample.json \
  --ledger tests/fixtures/ledger.sample.json
```

## 四、提交前自检

```bash
python3 bin/ledger.py check ...      # 若你改了检查逻辑，先用 fixtures 跑通
python3 bin/window.py dates --days 7  # 若你改了窗口口径，确认没退回 NOW-N 写法
git status --short                   # data/ logs/ *.json 不应出现在待提交列表里
```

PR 描述里请回答三个问题：**改了什么、为什么现在的写法是错的、怎么验证改对了**。

## 五、许可

贡献即表示同意以 [CC BY-NC-SA 4.0](LICENSE) 发布。请注意该许可**禁止商用**；如果你的用途是商业场景，请先联系维护者（通过 GitHub，不要用邮箱）。
